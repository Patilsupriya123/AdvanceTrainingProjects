package com.simplilearn;

import java.util.Scanner;

public class RectangleClass {
	
		 private int width = 0, length = 0;

		 public RectangleClass(int width, int length)
		  {
		   setWidth(width);
		   setLength(length);
		  }
		  void setWidth(int width){
		   this.width = width;
		  }
		  void setLength(int length) {
		   this.length = length;
		  }
		  int getWidth()
		  {
		   return this.width;
		  }
		  int getLength()
		  {
		   return this.length;
		  }
		  int getPerimeter()
		  {
		   return 2*getWidth() + 2*getLength();
		  }
		  int getArea()
		  {
		   return getWidth()*getLength();
		  }
		 
		 public static void main(String[] args)
		 {
		  Scanner scan = new Scanner(System.in);
		  System.out.println("Enter width:");
		  System.out.println("Enter length:");
		  int width=scan.nextInt();
		  int length=scan.nextInt();
		  RectangleClass rect = new RectangleClass(width, length);
		  System.out.println("Area: " + rect.getArea());
		  System.out.println("Perimeter: " + rect.getPerimeter());
		 }

		
}
