package com.simplilearn;

public abstract class Instrument {

	protected abstract void Play();
    
}