package com.simplilearn;


class Piano extends Instrument
	{
	public void Play()
		{
			System.out.println("Piano is playing tan tan tan tan");
		}
	}
	class Flute extends Instrument
		{
			public void Play()
			{
				System.out.println("Flute is playing toot toot toot toot");
			}
		}
		class Guitar extends Instrument
			{
				public void Play()
				{
					System.out.println("Guitar is playing tin tin tin ");
				}
			}

public class Music {

	public static void main(String[] args) 
		{
			Instrument i[] = new Instrument[10];
			i[0] = new Piano();
			i[1] = new Flute();
			i[2] = new Guitar();
			i[3] = new Piano();
			i[4] = new Flute();
			i[5] = new Guitar();
			i[6] = new Piano();
			i[7] = new Flute();
			i[8] = new Guitar();
			i[9] = new Piano();
	
			for ( int a = 0 ; a < i.length ; a++ )
				{
					if ( i[a] instanceof Piano )
					{
						System.out.println("Yes, It's Piano");
						i[a].Play();
					}
					if ( i[a] instanceof Flute )
					{
						System.out.println("Yes, It's Flute");
						i[a].Play();
					}
					if ( i[a] instanceof Guitar )
					{
						System.out.println("Yes, It's Guitar");
						i[a].Play();
					}
				}
		}

}
