package com.simplilearn;

public class StringExample {
		 
	static void printRotatedString(String str)
		    {
		        int l = str.length();
		        StringBuffer sb;
		        for (int a = 0; a < l; a++)
		        {
		            sb = new StringBuffer();
		            int b = a; 
		            int c = 0; 
		            for (int k2 = b; k2 < str.length(); k2++) {
		                sb.insert(c, str.charAt(b));
		                c++;
		                b++;
		            }
		            b = 0;
		            while (b < a)
		            {
		                sb.insert(c, str.charAt(b));
		                b++;
		                c++;
		            } 
		            System.out.println(sb);
		        }
		    }
		    public static void main(String[] args)
		    {
		        String  str = new String("MPHASIS");
		        printRotatedString(str);
		   }
	
}
