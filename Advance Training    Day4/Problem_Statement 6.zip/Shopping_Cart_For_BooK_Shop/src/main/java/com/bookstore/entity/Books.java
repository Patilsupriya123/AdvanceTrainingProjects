package com.bookstore.entity;

public class Books {

	String id;
	String Book_Name;
	String Author;
	Double Price;

	public Books() {
	}

	public Books(String id, String book_name, String author, Double price) {
		super();
		id = id;
		Book_Name = book_name;
		Author = author;
		Price = price;
	}

	public String getid() {
		return id;
	}

	public void setid(String book_id) {
		id = book_id;
	}

	public String getBook_name() {
		return Book_Name;
	}

	public void setBook_name(String book_name) {
		Book_Name = book_name;
	}

	public String getAuthor() {
		return Author;
	}

	public void setAuthor(String author) {
		Author = author;
	}

	public Double getPrice() {
		return Price;
	}

	public void setPrice(Double price) {
		Price = price;
	}

	@Override
	public String toString() {
		return "Books [Book_id=" + id + ", Book_name=" + Book_Name + ", Author=" + Author + ", Price=" + Price
				+ "]";
	}

}
