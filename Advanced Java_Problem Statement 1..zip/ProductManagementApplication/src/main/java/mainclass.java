

class Product{
	private int productid;
	private String productName;
	private int productPrice;
	
	Product(int productid , String productName ,int productPrice){
		this.productid =productid;
		this.productName=productName;
		this.productPrice=productPrice;
		
		
	}

	public int getproductid() {
		return productid;
	}
	public String getproductName() {
		return productName;
	}
	public int getProductprice() {
		return productPrice;
	}

	public String toString(){
		return productid + "" + productName + "" + productPrice;
	}
	
	
}