package com.simplilearn;

public class SLL {

	public static void main(String[] args) {
        LinkedList<Employee> linkedList = new LinkedList<Employee>(); 
        // creation of Linked List
        
        linkedList.insertFirst(new Employee("41", "Supriya","a1"));
        linkedList.insertFirst(new Employee("42", "komal","b1"));
        linkedList.insertFirst(new Employee("43", "Abhilasha","c1"));
        linkedList.insertFirst(new Employee("44", "sapna","d1"));
        linkedList.insertFirst(new Employee("45", "rohini","e1"));

        linkedList.displayLinkedList();
  }
}
