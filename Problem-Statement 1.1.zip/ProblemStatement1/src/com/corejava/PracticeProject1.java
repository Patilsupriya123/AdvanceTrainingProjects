package com.corejava;

import java.util.Scanner;

public class PracticeProject1 {

	public static void main(String[] args) {
		
		 int n=0,a=0;

         

	       Scanner sc = new Scanner(System.in);

	         

	       System.out.print("Enter value n : ");

	       n = sc.nextInt();

	         

	       for(a=1; a<n; a++)

	       {

	           if(a%2==0)

	               System.out.print(a+" ");

	       }    

	       System.out.println();

	         

	   }
	
}
