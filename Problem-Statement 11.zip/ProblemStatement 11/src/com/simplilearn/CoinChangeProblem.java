package com.simplilearn;

import java.util.Scanner;
import java.util.Vector;

public class CoinChangeProblem {		  
		   
	    static int denomination[] = {1, 2, 5, 10, 20, 50, 100, 500, 1000};
	    static int n = denomination.length;
	  
	    static void findMin(int X)
	    {
	   	        Vector<Integer> vector = new Vector<>();
	  
	       	        for (int a = n - 1; a >= 0; a--)
	        {
	           
	            while (X >= denomination[a]) 
	            {
	                X -= denomination[a];
	                vector.add(denomination[a]);
	            }
	        }
	  
	        
	        for (int b = 0; b < vector.size(); b++)
	        {
	            System.out.print(" " + vector.elementAt(b));
	                
	            
	        }
	        System.out.println("\n The minimum number of coins is "+vector.size());
	    }
	  
	   
	    public static void main(String[] args) 
	    {
	    	 Scanner scan=new Scanner(System.in);
	    	   System.out.println("Enter the Number");
	    	   int n=scan.nextInt();
	        
	    	   
	        System.out.print(" Following is minimal number " +"of change for " + n + ": ");
	        findMin(n);
	    
	}
}
