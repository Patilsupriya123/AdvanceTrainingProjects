package com.simplilearn;

import java.util.HashSet;

public class RepeatingElementArray {
	 	
	    static void FirstRepeatingElement(int array[])
	    {
	       
	        int min = -1;
	 

	        HashSet<Integer> set = new HashSet<>();
	 
	       
	        for (int a=array.length-1; a>=0; a--)
	        {
	            
	            if (set.contains(array[a]))
	                min = a;
	 
	            else   
	                set.add(array[a]);
	        }
	 
	       
	        if (min != -1)
	          System.out.println("First Repeating Element is:  " + array[min]);
	        else
	          System.out.println("There are no repeating elements");
	    }
	 
	    
	    public static void main (String[] args) throws java.lang.Exception
	    {
	        int arr1[] = {1, 2, 3, 10, 2, 4, 5, 7, 8 };
	        FirstRepeatingElement(arr1);
	        
	        int arr2[] = {1, 2, 3, 10, 6, 4, 3, 7, 10};
	        FirstRepeatingElement(arr2);
	        
	        
	    }
}



