package com.simplilearn;

public class MedicineTest {
	
	public static void main(String[] args)
	{
		Medicine med[] = new Medicine[10];
		double i = Math.random()*4;
		int j = (int) i;
		System.out.println(j);
		switch(j)
		{
			case 1: med[0] = new Medicine();
			med[1] = new Tablet();
			med[0].displayLabel();
			med[1].displayLabel();
			break;
			
			case 2: med[2] = new Medicine();
			med[3] = new Syrup();
			med[2].displayLabel();
			med[3].displayLabel();
			break;
			
			case 3: med[4] = new Medicine();
			med[5] = new Ointment();
			med[4].displayLabel();
			med[5].displayLabel();
			break;
			default: System.out.println("Invalid Choice");
		}
	}
}
