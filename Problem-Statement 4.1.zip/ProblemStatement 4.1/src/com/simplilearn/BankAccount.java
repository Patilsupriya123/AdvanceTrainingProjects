package com.simplilearn;

public class BankAccount {
    	
		int AccountNo;
    	String Name;
    	String AccountType;
    	double Balance;
   
    public int getAccountNo() {
			return AccountNo;
		}
		public void setAccountNo(int accountNo) {
			AccountNo = accountNo;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public String getAccountType() {
			return AccountType;
		}
		public void setAccountType(String accountType) {
			AccountType = accountType;
		}
	public double getBalance() {
       
        if( Balance <1000)
        {
        try
        {   
            throw new NumberFormatException();
        }
        catch(NumberFormatException nw)
        	{
            	System.out.println("Balance is low"+Balance);
        	}
        }
      
        return Balance;
       
    }
    public void setBalance(double balance) {
        this.Balance = balance;
    }

    public BankAccount() {
       
        this.AccountNo = 301;
        this.Name = "AMOl";
        this.AccountType = "Saving";
        this.Balance = 25000;
    }
   
  
    public BankAccount(int account_number, String name, String account_type,
            double balance) {
       
        this.AccountNo = account_number;
        this.Name = name;
        this.AccountType = account_type;
        this.Balance = balance;
    }
    void deposit(double amount)
    {
        if(amount<0)
        {
            try
            {
                throw new NumberFormatException();
            }
            catch(NumberFormatException nf)
            {
                System.out.println("Negaive Amount cant be deposited");
            }
        }
        else
        {
            Balance=getBalance()+amount;
            System.out.println("Current balance is ="+Balance);
        }
      
    }
     public void withdraw(double amount){
         if(amount>1000)
            {
                try
                {
                    throw new NumberFormatException();
                }
                catch(NumberFormatException e)
                {
                    System.out.println("WE CANT DEPOSITE AMOUNT INSUFFICENT BALANCE ");
                }
            }
            else
            {
                Balance=getBalance()-amount;
                System.out.println("Current balance is ="+Balance);
               
            }
 
    }
     void display()
     {
    System.out.println("Balance is ="+getBalance());   
     }
   
    public static void main(String[] args) {
       
        BankAccount b=new BankAccount();
        b.deposit(4000);
        b.display();
        b.withdraw(900);
        b.display();
        b.withdraw(6000);
        b.getBalance();
        b.display();
      
    }
 
}
