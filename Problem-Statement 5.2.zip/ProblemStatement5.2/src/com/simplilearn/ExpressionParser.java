package com.simplilearn;

public class ExpressionParser {

public static void main(String[] args) {
		
		
		String str= (" 23  +  45  -  (  343  /  12  ) ");
		String[] w=str.split("\\s");
		
		for(String s:w){  
			System.out.println(s); 
		}
	}

}
