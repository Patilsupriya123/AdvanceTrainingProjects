package com.simplilearn;

public class Serialization {

}
